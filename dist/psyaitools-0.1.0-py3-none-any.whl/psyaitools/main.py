# -*- coding: utf-8 -*-

def helloworld():
    print("Hello World!")

def main():
    helloworld()

# if __name__ == "__main__":
#     main()